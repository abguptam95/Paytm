# spring-boot-paytm-integration
How to do payment integration using paytm with Spring Boot

# Testing Integration URL 
https://developer.paytm.com/docs/testing-integration/
